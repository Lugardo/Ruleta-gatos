<?php
/**
 * Copia este archivo a config.php y rellena con los datos
 * que te da Hostinger en:
 *   hPanel > Bases de datos > MySQL
 *
 * config.php NO se sube a git (está en .gitignore).
 */

$DB_HOST = '127.0.0.1:3306';      // En Hostinger casi siempre es 'localhost'
$DB_NAME = 'u774478823_ruletagatos'; // Nombre de tu base de datos MySQL
$DB_USER = 'u774478823_ruletagatos';   // Usuario MySQL
$DB_PASS = 'Ketiva12-';    // Contraseña MySQL
