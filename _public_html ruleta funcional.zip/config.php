<?php
$DB_HOST = 'localhost';
$DB_NAME = 'u774478823_ruletagatos';
$DB_USER = 'u774478823_ruletagatos';
$DB_PASS = 'RuletaGatos2026';